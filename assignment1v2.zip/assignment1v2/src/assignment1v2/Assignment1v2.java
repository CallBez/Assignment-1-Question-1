/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignment1v2;

import java.util.Scanner;

public class Assignment1v2 {


    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        Student studentManager = new Student();
        Menu mainMenu = new Menu();
        
        boolean exit = false;
        
        while (!exit) {
            System.out.println("Enter (1) to launch menu or any other key to exit: ");
            String launchChoice = sc.nextLine();

            if (!launchChoice.equals("1")) {
                exit = true;
                System.out.println("Exiting the application.");
                
                continue;
            }

            mainMenu.display();
            int choice = sc.nextInt();
            sc.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    studentManager.captureNewStudent(sc);
                    break;
                case 2:
                    studentManager.searchStudent(sc);
                    break;
                case 3:
                    studentManager.deleteStudent(sc);
                    break;
                case 4:
                    studentManager.StudentReport();
                    break;
                case 5:
                    exit = true;
                    System.out.println("Exiting the application.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}
  
