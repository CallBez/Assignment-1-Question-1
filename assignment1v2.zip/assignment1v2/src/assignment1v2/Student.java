/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment1v2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Student {
    
    //array list
    static List<StudentInformation> students = new ArrayList<>();
    
    //scanner object
    static Scanner sc = new Scanner(System.in);
    
    //method to capture new student 
    public void captureNewStudent(Scanner sc){
        
        System.out.println("Enter the student id: ");
        int id = sc.nextInt();
        sc.nextLine();
        
        System.out.println("Enter the student name: ");
        String name = sc.nextLine(); 
        
        System.out.println("Enter the student age: ");
        int age;
        while (true) {
            try {
                age = Integer.parseInt(sc.nextLine());
                if (age >= 16) {
                    break;
                }//end of if statement
                    else {
                    System.out.println("You have entered an incorrect age! Please re-enter the student age: ");
                }//end of else
            } catch (NumberFormatException e) {
                System.out.println("You have not entered a number! Please re-enter the student age: ");
            }
        }//end of while loop
        
        System.out.println("Enter the student email: ");
        String email = sc.nextLine();
        
        System.out.println("Enter the student course: ");
        String course = sc.nextLine();
        
       
        StudentInformation student = new StudentInformation(id, name, age, email, course);
         //adding the student inforamtion to the list
         students.add(student);
         
         System.out.println("Student details have been successfully saved!");
         
        
    }//end of new student method
    
    //method to search for student
    public void searchStudent(Scanner sc){
        
        System.out.println("Enter the student id to search: ");
        int searchId= sc.nextInt();
        sc.nextLine();
        
        boolean found = false;
        for (StudentInformation student : students) {
            if (student.id == searchId) {
                
                System.out.println("*******************************************");
                student.displayStudInfo();
                
                found = true;
                
                break;
            }//end of if statement
        }//end of for loop

        if (!found) {
            System.out.println("*******************************************");
            
            System.out.println("Student with Student ID: " + searchId + " was not found!");
            
            System.out.println("*******************************************");
        }//end of if statement
        
        
    }//end of search student method
    
    //method for when deleting a student 
    public void deleteStudent(Scanner sc) {
        
        System.out.println("Enter the student id to delete: ");
        int deleteId = sc.nextInt();
        sc.nextLine();
        
        for (int i = 0; i < students.size(); i++) {
            
            if (students.get(i).id == deleteId) {
                System.out.println("Are you sure you want to delete student " + deleteId + " from the system? Yes(y) to delete.");
                String confirmation = sc.nextLine();
                
                if (confirmation.equalsIgnoreCase("y")) {
                    students.remove(i);
                    
                    System.out.println("*******************************************");
                    
                    System.out.println("Student with Student ID " + deleteId + " WAS deleted!");
                    
                    System.out.println("*******************************************");
                }//end of if statement
                else {
                    System.out.println("Deletion canceled.");
                }
                return;
            }//end of if statement
        }//end of for loop

        System.out.println("Student with Student ID " + deleteId + " was not found!");
        
    }// end of delete student method
    
    //method to the print student report 
    public void StudentReport(){
        int studCount = 1;
        
                for (StudentInformation student : students) {
            System.out.println("Student " + studCount);
            System.out.println("*******************************************");
            student.displayStudInfo();
            System.out.println("*******************************************");
            studCount++;
        }
    }//end of student report method 
    
}//end of class
