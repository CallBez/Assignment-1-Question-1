/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package assignment1v2;

import java.util.List;
import java.util.Scanner;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author caleb
 */
public class StudentTest {
    
    @Test
    public void TestSaveStudent() {
        
        // Create a test instance of StudentManagement
        Student student = new Student();

        // Create a test instance of Scanner
        Scanner mockScanner = new Scanner("101\nJohn Doe\n18\njohndoe@example.com\nMath");

        // Capture a new student using the test input
        student.captureNewStudent(mockScanner);

        // Get the list of students from Student
        List<StudentInformation> students = Student.students;

        // Verify that the student has been saved correctly
        assertEquals(1, students.size()); // There should be one student in the list

        // Get the saved student
        StudentInformation savedStudent = students.get(0);

        // Verify the attributes of the saved student
        assertEquals(101, savedStudent.id);
        assertEquals("John Doe", savedStudent.name);
        assertEquals(18, savedStudent.age);
        assertEquals("johndoe@example.com", savedStudent.email);
        assertEquals("Math", savedStudent.course);
    }
    /*
    @Test
    public void TestSearchStudent() {
        
    }
    
    @Test
    public void TestSearchStudent_StudentNotFound(){
        
    }
    
    @Test
    public void TestDeleteStudent() {
        
    }
    
    @Test
    public void TestDeleteStudent_StudentNotFound() {
        
    }
    
    @Test
    public void TestStudentAge_StudentAgeValid() {
        
    }
    
    @Test
    public void TestStudentAge_StudentAgeInvalid() {
        
    }
    
    @Test
    public void TestStudentAge_StudentAgeInvalidCharacter() {
        
    }
    
    */
    
    
}
